"""구매 질문을 제한된 단일 SELECT 초안으로 변환하는 Text2SQL adapter."""

from __future__ import annotations

from app.core.config import get_settings
from mcp_servers.data_tools.purchase.schema import SchemaResource

SYSTEM_PROMPT = (
    "당신은 구매 데이터베이스 전용 SQL 생성기입니다. "
    "제공된 뷰(VIEW)와 컬럼만 사용해 MySQL 단일 SELECT 문을 생성하세요. "
    "쓰기 문장과 DDL을 생성하지 말고 LIMIT을 포함하세요. SQL만 출력하세요."
)

# API 키가 없을 때 쓰는 키워드 -> SQL 템플릿 매핑 (데모/오프라인 모드)
_FALLBACK_TEMPLATES: list[tuple[tuple[str, ...], str]] = [
    (
        ("지출", "발주액", "구매액", "총액"),
        "SELECT vendor_id, COUNT(po_id) as po_count, SUM(total_amount) as total_spend "
        "FROM v_purchase_order GROUP BY vendor_id ORDER BY total_spend DESC LIMIT 20;",
    ),
    (
        ("미지급", "outstanding"),
        "SELECT vendor_id, invoice_number, total_amount, outstanding_amount, status "
        "FROM v_vendor_invoice WHERE outstanding_amount > 0 "
        "ORDER BY outstanding_amount DESC LIMIT 50;",
    ),
    (
        ("상태", "Closed", "Sent"),
        "SELECT status, COUNT(po_id) as count, SUM(total_amount) as total "
        "FROM v_purchase_order GROUP BY status ORDER BY total DESC LIMIT 20;",
    ),
    (
        ("공급업체", "벤더", "vendor"),
        "SELECT vendor_id, vendor_name, country, payment_terms FROM v_vendor "
        "ORDER BY vendor_name LIMIT 50;",
    ),
    (
        ("품목", "상품", "구매"),
        "SELECT description, SUM(quantity) as total_qty, SUM(line_total) as total_amount "
        "FROM v_purchase_order_line GROUP BY description "
        "ORDER BY total_qty DESC LIMIT 20;",
    ),
]

_DEFAULT_FALLBACK_SQL = "SELECT * FROM v_purchase_order ORDER BY po_date DESC LIMIT 20;"


def _generate_sql_fallback(question: str) -> str:
    """API key가 없는 개발 환경에서 제한된 구매 SELECT 템플릿을 선택한다."""
    normalized = question.casefold()
    for keywords, sql in _FALLBACK_TEMPLATES:
        if any(keyword in normalized for keyword in keywords):
            return sql
    return _DEFAULT_FALLBACK_SQL


async def generate_sql(question: str, schema: SchemaResource) -> str:
    """구매 allowlist schema만 사용해 실행 전 재검증할 SELECT 초안을 만든다."""
    settings = get_settings()
    if not settings.openai_api_key:
        return _generate_sql_fallback(question)

    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=settings.openai_api_key)

    # 스키마 설명 구성 (뷰 기반)
    views = schema.get("views", schema.get("tables", []))
    columns = schema.get("columns", {})
    glossary = schema.get("business_glossary", {})

    schema_description = (
        f"허용된 뷰 (5개): {', '.join(views)}\n\n"
        f"각 뷰의 컬럼:\n"
    )

    for view, cols in columns.items():
        schema_description += f"  {view}: {', '.join(cols)}\n"

    schema_description += f"\n업무 용어:\n"
    for i, (term, definition) in enumerate(glossary.items()):
        if i >= 10:  # 처음 10개만
            break
        schema_description += f"  {term}: {definition}\n"

    response = await client.chat.completions.create(
        model=settings.openai_model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"스키마:\n{schema_description}\n\n질문: {question}"},
        ],
        temperature=0,
    )

    sql = response.choices[0].message.content or ""
    return sql.strip().strip("`").removeprefix("sql\n").strip()